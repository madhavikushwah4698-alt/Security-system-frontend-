import { apiUrl } from '../api';

export async function translateToEnglish(text: string, sourceLang?: string) {
  try {
    const response = await fetch(apiUrl('/api/translate'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ text, sourceLang }),
    });
    if (!response.ok) {
      return text;
    }
    const data = await response.json();
    return data.translated || text;
  } catch (error) {
    console.error('Translation request failed:', error);
    return text;
  }
}

export async function transcribeVoice(_base64Audio: string) {
  return 'Transcription is not currently enabled in this client build.';
}
