export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || '';

export function apiUrl(path: string) {
  if (!API_BASE_URL) {
    throw new Error(
      'VITE_API_BASE_URL is not configured. Set it in your frontend environment (or Vercel env vars) to the deployed backend URL.'
    );
  }
  return `${API_BASE_URL}${path}`;
}
