import React, { useState, useEffect } from 'react';
import { io } from 'socket.io-client';
import {
  MapPin,
  Users,
  Clock,
  Send,
  Siren,
  Languages,
  History,
  UserPlus,
  ShieldCheck,
  Settings,
  Database
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { EmergencyAlert, User, AuditLog } from './types';
import { translateToEnglish } from './services/geminiService';
import { apiUrl, API_BASE_URL } from './api';

interface StaffDashboardProps {
  user: User;
}

export default function StaffDashboard({ user }: StaffDashboardProps) {
  const [activeTab, setActiveTab] = useState<'ALERTS' | 'GUESTS' | 'USERS' | 'AUDIT'>('ALERTS');
  const [alerts, setAlerts] = useState<EmergencyAlert[]>([]);
  const [selectedAlert, setSelectedAlert] = useState<EmergencyAlert | null>(null);
  const [staffLog, setStaffLog] = useState<{ id: string; msg: string; time: string }[]>([]);
  const [newUpdate, setNewUpdate] = useState('');
  
  // Admin state
  const [guests, setGuests] = useState<User[]>([]);
  const [guestLogins, setGuestLogins] = useState<{ id: string; username: string; email?: string; room?: string; timestamp: string }[]>([]);
  const [systemUsers, setSystemUsers] = useState<User[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [newUserData, setNewUserData] = useState({ username: '', email: '', role: 'STAFF' as const });
  const [guestRoomDrafts, setGuestRoomDrafts] = useState<Record<string, string>>({});
  const [savingRoom, setSavingRoom] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const socket = io(API_BASE_URL || undefined, { withCredentials: true });

    fetch(apiUrl('/api/alerts'), { credentials: 'include' })
      .then((res) => res.json())
      .then((data) => setAlerts(data || []));

    if (user.role === 'ADMIN') {
      fetch(apiUrl('/api/personnel'), { credentials: 'include' }).then((res) => res.json()).then((data) => setSystemUsers(data || []));
      fetch(apiUrl('/api/guests'), { credentials: 'include' }).then((res) => res.json()).then((data) => setGuests(data || []));
      fetch(apiUrl('/api/audit-logs'), { credentials: 'include' }).then((res) => res.json()).then((data) => setAuditLogs(data || []));
      socket.on('new_audit_log', (log: AuditLog) => {
        setAuditLogs((prev) => [log, ...prev]);
      });
    }

    socket.on('new_alert', async (alert: EmergencyAlert) => {
      if (alert.guestInfo?.originalMessage) {
        const translated = await translateToEnglish(alert.guestInfo.originalMessage, alert.guestInfo.language);
        alert = { ...alert, guestInfo: { ...alert.guestInfo, translatedMessage: translated } };
      }
      setAlerts((prev) => [alert, ...prev]);
      setStaffLog((prev) => [
        { id: `${alert.id}-new`, msg: `🚨 ALERT: ${alert.type} in Room ${alert.room}.`, time: new Date().toLocaleTimeString() },
        ...prev
      ]);
    });

    socket.on('alert_updated', (updatedAlert: EmergencyAlert) => {
      setAlerts((prev) => prev.map((alert) => (alert.id === updatedAlert.id ? updatedAlert : alert)));
      setSelectedAlert((current) => (current?.id === updatedAlert.id ? updatedAlert : current));
      setStaffLog((prev) => [
        { id: `${updatedAlert.id}-update`, msg: `🔄 Alert ${updatedAlert.type} updated to ${updatedAlert.status}.`, time: new Date().toLocaleTimeString() },
        ...prev
      ]);
    });

    socket.on('guest_logged_in', (guest: { id: string; username: string; email?: string; room?: string; timestamp: string }) => {
      setGuestLogins((prev) => [guest, ...prev]);
    });

    return () => {
      socket.disconnect();
    };
  }, [user.role]);

  const updateAlertStatus = async (id: string, status: EmergencyAlert['status']) => {
    const res = await fetch(apiUrl(`/api/alerts/${id}`), {
      method: 'PATCH',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    });
    if (res.ok) {
      const updatedAlert = await res.json();
      setAlerts((prev) => prev.map((alert) => (alert.id === updatedAlert.id ? updatedAlert : alert)));
      setSelectedAlert((current) => (current?.id === updatedAlert.id ? updatedAlert : current));
    }
  };

  const addUpdate = async () => {
    if (!selectedAlert || !newUpdate.trim()) return;
    const update = {
      message: newUpdate.trim(),
      staffName: user.username
    };
    const res = await fetch(apiUrl(`/api/alerts/${selectedAlert.id}/updates`), {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(update)
    });
    if (res.ok) {
      const updatedAlert = await res.json();
      setAlerts((prev) => prev.map((alert) => (alert.id === updatedAlert.id ? updatedAlert : alert)));
      setSelectedAlert(updatedAlert);
      setNewUpdate('');
      setStaffLog((prev) => [
        { id: `${updatedAlert.id}-note`, msg: `📝 ${user.username} posted an update for Room ${updatedAlert.room}.`, time: new Date().toLocaleTimeString() },
        ...prev
      ]);
    }
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch(apiUrl('/api/personnel'), {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newUserData)
    });
    if (res.ok) {
      const newUser = await res.json();
      setSystemUsers((prev) => [...prev, newUser]);
      setNewUserData({ username: '', email: '', role: 'STAFF' });
    }
  };

  const updateGuestRoom = async (guestId: string) => {
    const room = (guestRoomDrafts[guestId] || '').trim();
    if (!room) return;
    setSavingRoom((prev) => ({ ...prev, [guestId]: true }));

    try {
      const res = await fetch(`/api/users/${guestId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ room })
      });
      if (!res.ok) return;
      const updatedUser = await res.json();
      setGuests((prev) => prev.map((guest) => guest.id === updatedUser.id ? { ...guest, room: updatedUser.room } : guest));
      setGuestRoomDrafts((prev) => ({ ...prev, [guestId]: updatedUser.room || '' }));
    } finally {
      setSavingRoom((prev) => ({ ...prev, [guestId]: false }));
    }
  };

  const protocolSteps = selectedAlert ? (
    {
      FIRE: ['Activate the fire alarm immediately.', 'Ensure guests evacuate via nearest safe exit.', 'Keep stairwells open and secure elevators.', 'Meet emergency services at entrance.', 'Confirm accountability for all guests and staff.'],
      MEDICAL: ['Call ambulance with room and floor details.', 'Keep corridors clear for rapid access.', 'Prepare guest health information.', 'Dispatch trained staff to assist.', 'Log response updates until closed.'],
      SECURITY: ['Secure the area and prevent escalation.', 'Collect witness details and preserve evidence.', 'Notify authorities if threat escalates.', 'Guide guests to safe zones.', 'Debrief and document incident details.']
    } as Record<string, string[]>
  )[selectedAlert.type] || [] : [];

  return (
    <div className="flex flex-col h-screen bg-[#0A0A0B] text-slate-200 overflow-hidden font-sans">
      <nav className="h-16 border-b border-white/10 bg-[#0F0F12] flex items-center justify-between px-6 shrink-0 z-50 shadow-2xl">
        <div className="flex items-center gap-8">
          <div className="flex items-center gap-3">
            <div className="bg-red-600 p-2 rounded text-white shadow-lg shadow-red-600/20">
              <Siren size={20} />
            </div>
            <span className="text-xl font-black tracking-tight text-white uppercase italic">
              Crisis<span className="text-red-500">Connect</span>
            </span>
          </div>
          
          <div className="flex border-l border-white/10 pl-8 gap-1">
            <button 
              onClick={() => setActiveTab('ALERTS')}
              className={`px-4 py-1.5 text-[10px] font-black uppercase tracking-widest rounded-lg transition-all ${activeTab === 'ALERTS' ? 'bg-white/10 text-white border border-white/10' : 'text-slate-500 hover:text-slate-300'}`}
            >
              Alerts
            </button>
            {user.role === 'ADMIN' && (
              <>
                <button 
                  onClick={() => setActiveTab('GUESTS')}
                  className={`px-4 py-1.5 text-[10px] font-black uppercase tracking-widest rounded-lg transition-all ${activeTab === 'GUESTS' ? 'bg-white/10 text-white border border-white/10' : 'text-slate-500 hover:text-slate-300'}`}
                >
                  Manage Guests
                </button>
                <button 
                  onClick={() => setActiveTab('USERS')}
                  className={`px-4 py-1.5 text-[10px] font-black uppercase tracking-widest rounded-lg transition-all ${activeTab === 'USERS' ? 'bg-white/10 text-white border border-white/10' : 'text-slate-500 hover:text-slate-300'}`}
                >
                  Personnel
                </button>
                <button 
                  onClick={() => setActiveTab('AUDIT')}
                  className={`px-4 py-1.5 text-[10px] font-black uppercase tracking-widest rounded-lg transition-all ${activeTab === 'AUDIT' ? 'bg-white/10 text-white border border-white/10' : 'text-slate-500 hover:text-slate-300'}`}
                >
                  Audit Logs
                </button>
              </>
            )}
          </div>
        </div>
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 bg-green-500/10 px-3 py-1 rounded-full border border-green-500/20">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-[10px] font-bold text-green-500 tracking-widest uppercase">Node Active: {user.username}</span>
          </div>
        </div>
      </nav>

      <main className="flex flex-1 overflow-hidden relative">
        <AnimatePresence mode="wait">
          {activeTab === 'ALERTS' ? (
            <motion.div 
              key="alerts"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="flex-1 flex overflow-hidden w-full"
            >
              {/* Sidebar: Active Alerts */}
              <aside className="w-80 border-r border-white/10 bg-[#0F0F12] flex flex-col shrink-0">
                <div className="p-4 border-b border-white/5 bg-black/20">
                  <h2 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Active Emergency Stream ({alerts.filter(a => a.status !== 'RESOLVED').length})</h2>
                </div>
                <div className="flex-1 overflow-y-auto">
                  {alerts.length === 0 ? (
                    <div className="p-8 text-center text-slate-600 italic text-xs uppercase tracking-widest bg-black/10 h-full flex items-center justify-center">No Active Threats</div>
                  ) : alerts.map(alert => (
                    <button 
                      key={alert.id}
                      onClick={() => setSelectedAlert(alert)}
                      className={`w-full p-4 border-b border-white/5 text-left transition-all relative ${
                        selectedAlert?.id === alert.id ? 'bg-red-500/10 border-l-4 border-red-600' : 'hover:bg-white/5'
                      } ${alert.status === 'RESOLVED' ? 'opacity-40 grayscale' : ''}`}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <span className={`font-black text-[10px] tracking-widest uppercase ${
                          alert.type === 'FIRE' ? 'text-red-500' :
                          alert.type === 'MEDICAL' ? 'text-blue-500' : 'text-slate-200'
                        }`}>
                          {alert.type} INCIDENT
                        </span>
                        <span className="text-[10px] text-slate-500 font-mono italic">{new Date(alert.timestamp).toLocaleTimeString()}</span>
                      </div>
                      <p className="text-white font-bold text-sm">Room {alert.room} • {alert.guestCount} Guests</p>
                      <p className="text-[10px] text-slate-500 mt-1 uppercase font-bold tracking-tight">Floor {alert.floor} • Awaiting Dispatch</p>
                    </button>
                  ))}
                </div>
              </aside>

              {/* Coordination Dashboard */}
              <div className="flex-1 flex flex-col bg-[#0A0A0B] p-6 gap-6 overflow-y-auto overflow-x-hidden">
                <AnimatePresence mode="wait">
                  {selectedAlert ? (
                    <motion.div key={selectedAlert.id} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="flex flex-col gap-6">
                      <header className="flex justify-between items-end bg-[#141417] p-6 rounded-2xl border border-white/10">
                        <div>
                          <div className="flex items-center gap-3 mb-2">
                            <span className="px-2 py-0.5 bg-red-600 text-white text-[10px] font-black rounded uppercase">Critical</span>
                            <h1 className="text-3xl font-light text-white tracking-tight uppercase italic">{selectedAlert.type}: <span className="font-bold">Room {selectedAlert.room}</span></h1>
                          </div>
                          <p className="text-slate-500 text-xs font-bold uppercase tracking-widest ml-1">Dispatch Origin: ID-{selectedAlert.id.substring(0,8)}</p>
                        </div>
                        <div className="flex gap-2">
                          <button 
                            onClick={() => updateAlertStatus(selectedAlert.id, 'RESOLVED')}
                            className="px-6 py-2 bg-green-600/10 border border-green-600/30 text-green-500 text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-green-600/20 transition-all"
                          >
                            Resolve Alert
                          </button>
                        </div>
                      </header>

                      {/* Stats grid, templates, updates same as before but using the user.username */}
                      <div className="grid grid-cols-5 gap-4">
                        {[
                          { label: 'Latency', value: '00:04', icon: Clock },
                          { label: 'Response', value: 'Active', icon: Siren },
                          { label: 'Integrity', value: 'Secure', icon: ShieldCheck },
                          { label: 'Origin', value: `Rm ${selectedAlert.room}`, icon: MapPin },
                          { label: 'Operator', value: user.username, icon: Users }
                        ].map((stat, idx) => (
                          <div key={idx} className="bg-[#141417] border border-white/5 rounded-xl p-4 flex flex-col items-center justify-center text-center">
                             <stat.icon size={16} className="text-slate-600 mb-2" />
                             <div className="text-[9px] uppercase font-black text-slate-500 tracking-widest mb-1">{stat.label}</div>
                             <div className="text-xs font-mono font-bold text-white uppercase">{stat.value}</div>
                          </div>
                        ))}
                      </div>

                      <div className="grid grid-cols-2 gap-6">
                        <section className="bg-[#141417] border border-white/10 rounded-2xl p-6 flex flex-col shadow-2xl">
                          <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-6 border-b border-white/5 pb-2 italic">Intelligence Intercept</h3>
                          <div className="bg-black/40 p-4 rounded-xl border border-white/5 mb-4 italic text-sm text-slate-400">"{selectedAlert.guestInfo?.originalMessage || 'No voice/text data captured.'}"</div>
                          {selectedAlert.guestInfo?.translatedMessage && (
                             <div className="bg-blue-500/5 p-4 rounded-xl border border-blue-500/20 text-sm font-bold text-blue-100 flex items-start gap-3">
                                <Languages size={14} className="text-blue-500 mt-1 shrink-0" />
                                <span>"{selectedAlert.guestInfo.translatedMessage}"</span>
                             </div>
                           )}
                        </section>

                        <section className="bg-[#141417] border border-white/10 rounded-2xl p-6 shadow-2xl">
                          <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-6 border-b border-white/5 pb-2 italic">Action Protocol</h3>
                          <div className="space-y-4">
                            {(protocolSteps.length > 0 ? protocolSteps : ['No protocol available for this alert type.']).map((step, idx) => (
                              <div key={idx} className="bg-black/30 border border-white/5 rounded-2xl p-4">
                                <div className="text-[9px] font-bold uppercase tracking-[0.3em] text-slate-500 mb-2">Step {idx + 1}</div>
                                <p className="text-sm text-slate-200 leading-6">{step}</p>
                              </div>
                            ))}
                          </div>
                        </section>
                      </div>

                      <div className="bg-[#141417] border border-white/10 rounded-2xl overflow-hidden flex flex-col shadow-2xl">
                        <div className="p-6 border-b border-white/5 flex items-center gap-4">
                          <div className="flex-1 relative">
                            <input 
                              type="text" value={newUpdate} onChange={(e) => setNewUpdate(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && addUpdate()}
                              placeholder="Type incident update..." className="w-full bg-black/40 border border-white/5 rounded-xl px-6 py-4 text-xs font-bold uppercase tracking-widest text-slate-200 placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-red-600 transition-all"
                            />
                          </div>
                          <button onClick={addUpdate} className="bg-red-600 hover:bg-red-700 text-white px-8 py-4 rounded-xl flex items-center gap-3 transition-colors active:scale-95 group shadow-lg shadow-red-600/20">
                             <span className="text-[10px] font-black uppercase tracking-widest">Post</span>
                             <Send size={14} className="group-hover:translate-x-1 transition-transform" />
                          </button>
                        </div>
                        <div className="p-6 bg-black/20 max-h-48 overflow-y-auto space-y-4">
                           {selectedAlert.updates.map((upd, idx) => (
                             <div key={idx} className="flex gap-6 items-start">
                                <span className="text-[9px] font-mono text-slate-700 uppercase pt-1">{upd.time}</span>
                                <div className="flex-1 bg-white/5 border border-white/5 p-4 rounded-xl">
                                   <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest block mb-1">{upd.staffName}</span>
                                   <p className="text-xs font-bold text-slate-300 uppercase tracking-tight">{upd.message}</p>
                                </div>
                             </div>
                           ))}
                        </div>
                      </div>
                    </motion.div>
                  ) : (
                    <div className="h-full flex flex-col items-center justify-center text-slate-800 pointer-events-none select-none">
                       <Siren size={120} className="mb-8 opacity-20" />
                       <h2 className="text-6xl font-black uppercase italic tracking-tighter opacity-10 leading-none">Command</h2>
                       <h2 className="text-6xl font-black uppercase italic tracking-tighter opacity-10 leading-none">Node</h2>
                    </div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          ) : activeTab === 'USERS' ? (
            <motion.div 
              key="users"
              initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
              className="flex-1 p-8 overflow-y-auto"
            >
              <div className="max-w-5xl mx-auto grid grid-cols-3 gap-10">
                <div className="col-span-2">
                  <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter mb-8 flex items-center gap-3">
                    <Users className="text-red-500" />
                    Authorized Personnel
                  </h2>
                  <div className="space-y-4">
                    {systemUsers.map(u => (
                      <div key={u.id} className="bg-[#141417] border border-white/10 rounded-2xl p-6 flex justify-between items-center group hover:border-white/20 transition-all">
                        <div className="flex items-center gap-4">
                          <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-black ${u.role === 'ADMIN' ? 'bg-red-600/10 text-red-500' : 'bg-blue-600/10 text-blue-500'}`}>
                            {u.username.substring(0,2).toUpperCase()}
                          </div>
                          <div>
                            <div className="text-sm font-bold text-white uppercase tracking-widest">{u.username}</div>
                            <div className="text-[10px] text-slate-500 font-black uppercase tracking-widest flex gap-2 mt-1">
                              <span className={u.role === 'ADMIN' ? 'text-red-600' : 'text-blue-500'}>{u.role}</span>
                              {u.room && <span>• Room {u.room}</span>}
                            </div>
                          </div>
                        </div>
                        <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button className="p-2 hover:text-white text-slate-600 transition-colors"><Settings size={16} /></button>
                          <button className="p-2 hover:text-red-500 text-slate-600 transition-colors"><Siren size={16} /></button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <div className="bg-[#141417] border border-red-600/20 rounded-3xl p-8 shadow-2xl sticky top-0">
                    <h3 className="text-sm font-black text-white uppercase italic tracking-widest mb-6 flex items-center gap-3">
                      <UserPlus className="text-red-500" size={18} />
                      Provision New Personnel
                    </h3>
                    <p className="text-[10px] text-slate-500 uppercase tracking-[0.35em] mb-4">
                      Staff and admin accounts are managed separately from guest registrations.
                    </p>
                    <form onSubmit={handleCreateUser} className="space-y-4">
                      <input 
                        type="text" placeholder="Username / Employee ID" value={newUserData.username} onChange={e => setNewUserData({...newUserData, username: e.target.value})}
                        className="w-full bg-black border border-white/5 px-4 py-3 rounded-xl text-xs font-bold text-white placeholder:text-slate-700"
                      />
                      <input 
                        type="email" placeholder="Email Address" value={newUserData.email} onChange={e => setNewUserData({...newUserData, email: e.target.value})}
                        className="w-full bg-black border border-white/5 px-4 py-3 rounded-xl text-xs font-bold text-white placeholder:text-slate-700"
                      />
                      <select 
                        value={newUserData.role} onChange={e => setNewUserData({...newUserData, role: e.target.value as any})}
                        className="w-full bg-black border border-white/5 px-4 py-3 rounded-xl text-xs font-bold text-slate-400"
                      >
                        <option value="STAFF">Staff Member</option>
                      </select>
                      <button className="w-full py-4 bg-red-600 hover:bg-red-700 text-white rounded-xl font-black uppercase tracking-[0.2em] text-[10px] transition-all shadow-lg shadow-red-600/20">
                         Authorize Member
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            </motion.div>
          ) : activeTab === 'GUESTS' ? (
            <motion.div 
              key="guests"
              initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
              className="flex-1 p-8 overflow-y-auto"
            >
              <div className="max-w-5xl mx-auto">
                <div className="flex items-center justify-between mb-8">
                  <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter flex items-center gap-3">
                    <Users className="text-red-500" />
                    Manage Guests
                  </h2>
                  <div className="bg-[#141417] px-4 py-2 rounded-xl border border-white/5 flex gap-4 text-[10px] font-black uppercase tracking-widest text-slate-500">
                     <span>Live guest activity</span>
                     <span className="text-green-500">Online</span>
                  </div>
                </div>

                <div className="grid gap-6 lg:grid-cols-[1.6fr_0.9fr] mb-8">
                  <div className="bg-[#141417] border border-white/10 rounded-2xl overflow-hidden shadow-2xl">
                    <div className="p-6 border-b border-white/10">
                      <div className="flex items-center justify-between gap-4">
                        <div>
                          <h3 className="text-sm font-black uppercase tracking-widest text-slate-400">Guest Accounts</h3>
                          <p className="text-[10px] text-slate-500 mt-1">Total registered guests available for review.</p>
                        </div>
                        <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">{guests.length} guests</span>
                      </div>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-[11px]">
                        <thead className="bg-black/40 border-b border-white/10">
                          <tr>
                            <th className="px-5 py-4 text-slate-500 uppercase tracking-widest">Username</th>
                            <th className="px-5 py-4 text-slate-500 uppercase tracking-widest">Email</th>
                            <th className="px-5 py-4 text-slate-500 uppercase tracking-widest">Assigned Room</th>
                            <th className="px-5 py-4 text-slate-500 uppercase tracking-widest">Action</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5">
                          {guests.map((guest) => (
                            <tr key={guest.id} className="hover:bg-white/5 transition-colors">
                              <td className="px-5 py-4 text-white font-bold uppercase tracking-tight">{guest.username}</td>
                              <td className="px-5 py-4 text-slate-400 lowercase">{guest.email || '—'}</td>
                              <td className="px-5 py-4">
                                <input
                                  type="text"
                                  value={guestRoomDrafts[guest.id] ?? guest.room ?? ''}
                                  onChange={(e) => setGuestRoomDrafts((prev) => ({ ...prev, [guest.id]: e.target.value }))}
                                  className="w-full bg-black/20 border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder:text-slate-500"
                                  placeholder="Enter room"
                                />
                              </td>
                              <td className="px-5 py-4">
                                <button
                                  onClick={() => updateGuestRoom(guest.id)}
                                  disabled={savingRoom[guest.id]}
                                  className="px-3 py-2 bg-red-600 text-[10px] font-black uppercase tracking-widest rounded-xl disabled:opacity-40 disabled:cursor-not-allowed"
                                >
                                  {savingRoom[guest.id] ? 'Saving…' : 'Assign'}
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div className="bg-[#141417] border border-white/10 rounded-2xl p-6 shadow-2xl">
                    <h3 className="text-sm font-black uppercase tracking-widest text-slate-400 mb-4">Recent Guest Logins</h3>
                    <div className="space-y-3 max-h-[420px] overflow-y-auto pr-2">
                      {guestLogins.length === 0 ? (
                        <div className="bg-black/30 border border-white/5 rounded-2xl p-4 text-[10px] text-slate-500 uppercase tracking-[0.35em] text-center">
                          Waiting for guest logins...
                        </div>
                      ) : guestLogins.slice(0, 8).map((login) => (
                        <div key={login.id} className="bg-black/30 border border-white/5 rounded-3xl p-4 text-[11px] text-slate-200">
                          <div className="flex items-center justify-between gap-2 mb-2">
                            <span className="font-black uppercase tracking-wider text-slate-400">{login.username}</span>
                            <span className="text-[9px] text-slate-500 uppercase tracking-[0.3em]">{new Date(login.timestamp).toLocaleTimeString()}</span>
                          </div>
                          <div className="text-[10px] text-slate-300">{login.email || 'No email'}</div>
                          <div className="text-[10px] text-slate-500 uppercase tracking-[0.3em] mt-2">Room: {login.room || 'N/A'}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div 
              key="audit"
              initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
              className="flex-1 p-8 overflow-y-auto"
            >
              <div className="max-w-4xl mx-auto">
                <div className="flex items-center justify-between mb-8">
                  <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter flex items-center gap-3">
                    <History className="text-red-500" />
                    System Audit Trail
                  </h2>
                  <div className="bg-[#141417] px-4 py-2 rounded-xl border border-white/5 flex gap-4 text-[10px] font-black uppercase tracking-widest text-slate-500">
                     <span>Encryption: AES-256</span>
                     <span className="text-green-500">Active</span>
                  </div>
                </div>

                <div className="bg-[#141417] border border-white/10 rounded-2xl overflow-hidden shadow-2xl">
                  <table className="w-full text-left">
                    <thead className="bg-black/40 border-b border-white/5">
                      <tr>
                        <th className="px-6 py-4 text-[9px] font-black text-slate-500 uppercase tracking-widest">Timestamp</th>
                        <th className="px-6 py-4 text-[9px] font-black text-slate-500 uppercase tracking-widest">Operator</th>
                        <th className="px-6 py-4 text-[9px] font-black text-slate-500 uppercase tracking-widest">Action</th>
                        <th className="px-6 py-4 text-[9px] font-black text-slate-500 uppercase tracking-widest">Details</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5 italic">
                      {auditLogs.map(log => (
                        <tr key={log.id} className="hover:bg-white/5 transition-colors group">
                          <td className="px-6 py-4 text-[10px] font-mono text-slate-600 group-hover:text-slate-400">{new Date(log.timestamp).toLocaleString()}</td>
                          <td className="px-6 py-4 text-xs font-bold text-white uppercase tracking-tight">{log.username}</td>
                          <td className="px-6 py-4">
                            <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-tighter ${
                              log.action === 'LOGIN' ? 'text-blue-500 bg-blue-500/10' :
                              log.action === 'SOS_TRIGGERED' ? 'text-red-500 bg-red-600/10' :
                              log.action === 'USER_CREATED' ? 'text-green-500 bg-green-500/10' : 'text-slate-400 bg-white/5'
                            }`}>
                              {log.action}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-xs text-slate-500 uppercase tracking-tighter">{log.details}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Right Sidebar: Services Diagnostics (Visible on all tabs) */}
        <aside className="w-80 border-l border-white/10 bg-[#0F0F12] p-6 flex flex-col shrink-0 relative z-10">
           <div className="flex-1 flex flex-col overflow-hidden">
             <div className="flex-1 overflow-hidden flex flex-col">
               <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-6 border-b border-white/5 pb-2 italic flex items-center gap-2">
                  <Database size={12} /> Live Event Intercept
               </h3>
               <div className="space-y-4 overflow-y-auto pr-2">
                  {staffLog.map(log => (
                    <div key={log.id} className="p-4 bg-black/40 rounded-xl border border-white/5 text-[9px] font-bold text-red-500/80 leading-relaxed uppercase tracking-widest relative overflow-hidden">
                      <div className="absolute top-0 left-0 w-1 h-full bg-red-600/30"></div>
                      <div className="flex justify-between mb-2 text-slate-600 font-mono italic">
                        <span className="uppercase font-black text-[8px]">Sys_Packet</span>
                        <span>{log.time}</span>
                      </div>
                      {log.msg}
                    </div>
                  ))}

                  {user.role === 'ADMIN' && (
                    <div className="bg-[#141417] border border-white/10 rounded-2xl p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">User Activity</h3>
                        <span className="text-[8px] uppercase tracking-[0.35em] text-slate-400 bg-white/5 px-2 py-1 rounded-full">{auditLogs.length} events</span>
                      </div>
                      <div className="space-y-3 max-h-52 overflow-y-auto pr-1">
                        {auditLogs.slice(0, 5).map((log) => (
                          <div key={log.id} className="bg-black/30 border border-white/5 rounded-2xl p-3 text-[10px] text-slate-300">
                            <div className="font-black uppercase tracking-[0.25em] text-slate-500 mb-1">{log.username}</div>
                            <p className="leading-snug text-xs text-slate-200">{log.details}</p>
                            <div className="text-[8px] uppercase tracking-[0.35em] text-slate-600 mt-2">{new Date(log.timestamp).toLocaleTimeString()}</div>
                          </div>
                        ))}
                        {auditLogs.length === 0 && (
                          <div className="bg-black/30 border border-white/5 rounded-2xl p-4 text-[10px] text-slate-500 uppercase tracking-[0.35em] text-center">
                            No recent activity available.
                          </div>
                        )}
                      </div>
                    </div>
                  )}
               </div>
             </div>
           </div>

           <div className="pt-3 border-t border-white/10">
              <div className="grid grid-cols-1 gap-1">
                <div className="bg-slate-900/50 border border-white/10 rounded-2xl p-2.5 text-center">
                   <div className="text-[7px] font-black text-orange-400 uppercase tracking-widest mb-1">Fire</div>
                   <div className="text-xl font-black tracking-tighter text-white mb-0.5">101</div>
                   <p className="text-[7px] text-slate-500 uppercase tracking-widest">Fire Emergency</p>
                </div>
                <div className="bg-slate-900/50 border border-white/10 rounded-2xl p-2.5 text-center">
                   <div className="text-[7px] font-black text-cyan-400 uppercase tracking-widest mb-1">Ambulance</div>
                   <div className="text-xl font-black tracking-tighter text-white mb-0.5">108</div>
                   <p className="text-[7px] text-slate-500 uppercase tracking-widest">Medical Response</p>
                </div>
                <div className="bg-slate-900/50 border border-white/10 rounded-2xl p-2.5 text-center">
                   <div className="text-[7px] font-black text-red-500 uppercase tracking-widest mb-1">Emergency</div>
                   <div className="text-xl font-black tracking-tighter text-white mb-0.5">112</div>
                   <p className="text-[7px] text-slate-500 uppercase tracking-widest">General Emergency</p>
                </div>
              </div>
           </div>
        </aside>
      </main>
    </div>
  );
}

